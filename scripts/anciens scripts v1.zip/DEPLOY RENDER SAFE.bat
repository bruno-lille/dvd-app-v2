@echo off
setlocal
chcp 65001 >nul

cd /d %~dp0..

echo ============================
echo DEPLOY RENDER SAFE
echo ============================

:: 🔒 Ignorer films.db
git update-index --assume-unchanged films.db >nul 2>&1

echo.
echo [1/7] Nettoyage fichiers temporaires...

git restore .gitignore >nul 2>&1

echo.
echo [2/7] Status...
git status

echo.
echo [3/7] Ajout fichiers...

git add app.py
git add app_dev.py

:: 🔍 Y a-t-il des fichiers à commit ?
git diff --cached --quiet

IF %ERRORLEVEL% NEQ 0 (

    echo.
    echo [4/7] Commit local...

    git commit -m "V1 deploy"

    IF ERRORLEVEL 1 (
        echo.
        echo ❌ ERREUR commit
        pause
        exit /b
    )

) ELSE (

    echo.
    echo 🟡 Aucun nouveau fichier à commit
)

echo.
echo [5/7] Sync GitHub...

git pull origin main --rebase

IF ERRORLEVEL 1 (
    echo.
    echo ❌ ERREUR git pull
    pause
    exit /b
)

echo.
echo [6/7] Push GitHub / Render...

git push origin main

IF ERRORLEVEL 1 (
    echo.
    echo ❌ ERREUR PUSH
    pause
    exit /b
)

echo.
echo ============================
echo ✅ DEPLOY OK
echo ============================

pause